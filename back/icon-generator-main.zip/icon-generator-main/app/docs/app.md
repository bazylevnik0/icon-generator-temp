<b>interface:</b><br>

<b>three parts of screen:</b><br>

global navigation(full top):<br>
-search input<br>
-export<br>

edit tools(left):<br>
-three of elements<br>
-position<br>
-rotate<br>
-size<br>
-mirror<br>
-style<br>
-color<br>

preview/working screen(right):<br>
-drawing area<br>
-zoom in/out<br>
-grid on/off<br>
