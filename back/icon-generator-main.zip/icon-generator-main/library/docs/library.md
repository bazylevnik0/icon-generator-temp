GNOMe have two related projects:<br>
-https://gitlab.gnome.org/Teams/Design/icon-development-kit<br>
-https://gitlab.gnome.org/GNOME/adwaita-icon-theme<br>
-https://gitlab.gnome.org/Teams/Design/library-icons<br>
*icon-development-kit have good direction as a categories<br>
*advaita-icon-theme have a colofull complete icons<br>
*library-icons also need check<br>
also exist fontawesome(with 20000 icons))<br>

<b>goals for this library:</b><br>
1)make easy searching for simple symbols<br>
2)make full spectr of styles(HIG permissible)<br>
3)make easy to contibute to this lib<br>
4)make scalable structure for growing<br>

<b>structure:</b>
one folder for all library
<i>"name_tag_type_fill_parameters.svg"</i>



