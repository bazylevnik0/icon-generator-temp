<b>roadmap(test version):</b><br>
1)fill lib with test example <b><i>done</i></b><br>
2)write app prototype <b><i>in process</i></b>: <a href="app/docs/temp.md">app/temp</a><br>
3)create structure for contribute to lib<br>

