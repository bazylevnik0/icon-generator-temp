<b>conception:</b><br>
1)you make input of searching elements<br>
2)get few results<br>
3)edit them
4)export svg

<b>detailed conceptions of:</b><br>
-lib: <a href="/library/docs/library.md">/library/library.md</a><br>
-app: <a href="/app/docs/app.md">/app.md</a>

<b>look for process:</b> <a href="temp.md">temp</a>




